package capture;

import java.awt.Choice;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;

// Following to be imported if capturing traffic destined to this device
//import java.net.InetAddress;
//import java.net.UnknownHostException;

import org.jnetpcap.Pcap;
import org.jnetpcap.PcapDumper;
import org.jnetpcap.PcapIf;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.packet.PcapPacketHandler;
import org.jnetpcap.protocol.network.Icmp;
import org.jnetpcap.protocol.network.Ip4;
import org.jnetpcap.protocol.tcpip.Tcp;
import org.jnetpcap.protocol.tcpip.Udp;

public class PacketCaptureOnline implements IntervalPacketCapture{
	
	private Pcap pcap;  // Will be filled with NICs
	private List<PcapIf> alldevs = new ArrayList<PcapIf>();
	PcapDumper dumper;
	
    // For any error messages
	private StringBuilder errbuf = new StringBuilder();

	private long counter = 0;
	private long counterL = 0;
	private Choice choice;
	private JTextPane txtpnHello;
	private final String DATE_FORMAT_NOW = "yyyyMMddHHmmss";
    public static final int CAPTURE_INTERVAL = 5 * 1000; // 5 seconds in millis
	
	public PacketCaptureOnline(Choice choice, JTextPane txtpnHello) {
		this.choice = choice;
		this.txtpnHello = txtpnHello;
		try {
			choice.removeAll();
	        
			//Getting a list of devices
			int r = Pcap.findAllDevs(alldevs, errbuf);
			if (r != Pcap.OK) {
				txtpnHello.setText("Can't read list of devices, error is "+errbuf.toString());
				return;
			}
			
			//Printing the list of devices for user to choose one
			int i = 0;
			choice.setVisible(true);
			choice.setEnabled(true);
			for (PcapIf device : alldevs) {
				String description = (device.getDescription() != null) ? device.getDescription() : "No description available";
				choice.add(i+": "+device.getName()+" ["+description+"]");
				i++;
			}
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	//To capture online packets
	public long capture(LinkedList<PcapPacket> allPackets){
		
		counterL = 0;
        
        final long interval = System.currentTimeMillis() + CAPTURE_INTERVAL;
		
		
		//Create packet handler which will receive packets
		PcapPacketHandler<Object> jpacketHandler = new PcapPacketHandler<Object>() {
			
			Ip4 ip = new Ip4();
			Tcp tcp = new Tcp();
			Udp udp = new Udp();
			Icmp icmp = new Icmp();
			
			@Override
			public void nextPacket(PcapPacket packet, Object arg1) {
				
				// too stop the loop after 5 sec
				if (packet.getCaptureHeader().timestampInMillis() > interval) {  
                    pcap.breakloop();
                    return;
                }
				
				
				if (packet.hasHeader(ip))
				{
					counterL++;
					counter++;
					allPackets.add(new PcapPacket(packet));
					byte[] sIP = ip.source(); // Should be outside the callback method for efficiency
					byte[] dIP = ip.destination();
					
					// Use jNetPcap format utilities
					String sourceIP = org.jnetpcap.packet.format.FormatUtils.ip(sIP);
					String destinationIP = org.jnetpcap.packet.format.FormatUtils.ip(dIP);
					
					try {
						if(packet.hasHeader(tcp))
						{
							//Printing the source and destination address with port numbers
							txtpnHello.getStyledDocument().insertString(txtpnHello.getStyledDocument().getLength(), counter+"->TCP  "+sourceIP+":"+tcp.source()+","+destinationIP+":"+tcp.destination()+"\n", null);
						}
						else if(packet.hasHeader(udp))
						{
							//Printing the source and destination address with port numbers
							txtpnHello.getStyledDocument().insertString(txtpnHello.getStyledDocument().getLength(), counter+"->UDP  "+sourceIP+":"+udp.source()+","+destinationIP+":"+udp.destination()+"\n", null);						
						}
						else if(packet.hasHeader(icmp))
						{
							//Printing the source and destination address with port numbers
							txtpnHello.getStyledDocument().insertString(txtpnHello.getStyledDocument().getLength(), counter+"->ICMP  "+sourceIP+","+destinationIP+"\n", null);
						}
						else
						{
							//Printing the source and destination address
							txtpnHello.getStyledDocument().insertString(txtpnHello.getStyledDocument().getLength(), counter+"->"+sourceIP+","+destinationIP+"\n", null);
						}
					} catch (BadLocationException e) {
						e.printStackTrace();
					}
					
					dumper.dump(packet.getCaptureHeader(), packet);
					
				}
			}
		};
		
		//we enter the loop and capture the 100 packets here.You can  capture any number of packets just by changing the first argument to pcap.loop() function below
		//pcap.loop(100, jpacketHandler, "jnetpcap rocks!");
		
		//we enter the loop and capture INFINITE packets here.You can  capture any number of packets just by changing the first argument to pcap.loop() function below
		pcap.loop(Pcap.LOOP_INFINITE, jpacketHandler, dumper);
		
		
		return counterL;
	}
	
	//to open the device for capturing live packets
	public void open()
	{	
		int ch = choice.getSelectedIndex();		//User Choice
		PcapIf device = alldevs.get(ch);		//Device to be opened
		int snaplen = 64 * 1024;				// Capture all packets, no trucation
		int flags = Pcap.MODE_PROMISCUOUS;		// capture all packets
		int timeout = 5 * 1000;				// 5 seconds in millis
		
		//Open the selected device to capture packets
		pcap = Pcap.openLive(device.getName(), snaplen, flags, timeout, errbuf);
		if (pcap == null) {
			System.err.printf("Error while opening device for capture: "+ errbuf.toString());
			return;
		}
		
		//Dumper
		String ofile = "pcap" + now().toString() + ".pcap";  
        dumper = pcap.dumpOpen(ofile);
	}
	
	//To Stop the Loop
	public void quit()
	{
		try{
			pcap.breakloop();
			//Close the pcap
			pcap.close();
			
			//closing the dumper
			dumper.close();
			
		}
		catch(Exception e)
		{
			
		}
	}
	
	//For Current time
	private String now() {
		Calendar cal = Calendar.getInstance();  
		SimpleDateFormat df = new SimpleDateFormat(DATE_FORMAT_NOW);  
		return df.format(cal.getTime());  
	}
	
}