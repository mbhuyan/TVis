package capture;

import java.io.File;
import java.util.LinkedList;

import javax.swing.JTextPane;

import org.jnetpcap.Pcap;
import org.jnetpcap.PcapDumper;
import org.jnetpcap.nio.JMemory;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.protocol.JProtocol;
import org.jnetpcap.protocol.network.Icmp;
import org.jnetpcap.protocol.network.Ip4;
import org.jnetpcap.protocol.tcpip.Tcp;
import org.jnetpcap.protocol.tcpip.Udp;

public class PacketCaptureOffline implements IntervalPacketCapture{
	
	private Pcap pcap;  // Will be filled with NICs
	PcapDumper dumper;
	
    // For any error messages
	private StringBuilder errbuf = new StringBuilder();

	private long counter = 0;
	private long counterL = 0;
	private File file;
	private JTextPane txtpnHello;
	private long startTime;
	private int fileIterate = 1;
    
    
	public PacketCaptureOffline(File file, JTextPane txtpnHello) {
		this.file = file;
		this.txtpnHello = txtpnHello;
	}

	@Override
	public long capture(LinkedList<PcapPacket> allPackets) {
		
		Ip4 ip = new Ip4();
		Tcp tcp = new Tcp();
		Udp udp = new Udp();
		Icmp icmp = new Icmp();
		
		PcapPacket packet = new PcapPacket(JMemory.POINTER);
		counterL = 0;
		if(pcap.nextEx(packet) == Pcap.NEXT_EX_EOF)
		{
			return -1;
		}
		if(fileIterate==1)
		{
			startTime = packet.getCaptureHeader().timestampInMillis();
		}
		final long interval = startTime + 5000*fileIterate;
		fileIterate++;
		do
		{
			if(!packet.hasHeader(JProtocol.ETHERNET_ID))
			{
				packet.scan(JProtocol.IP4_ID);
			}
			
			//to read only 5 sec data
			if (packet.getCaptureHeader().timestampInMillis() > interval) {  
				break;
            }
			
			if (packet.hasHeader(ip))
			{
				counter++;
				counterL++;
				allPackets.add(new PcapPacket(packet));
				byte[] sIP = ip.source(); // Should be outside the callback method for efficiency
				byte[] dIP = ip.destination();
				
				// Use jNetPcap format utilities
				String sourceIP = org.jnetpcap.packet.format.FormatUtils.ip(sIP);
				String destinationIP = org.jnetpcap.packet.format.FormatUtils.ip(dIP);
				
				try {
					
					if(packet.hasHeader(tcp))
					{
						//Printing the source and destination address with port numbers
						txtpnHello.getStyledDocument().insertString(txtpnHello.getStyledDocument().getLength(), counter+"->TCP  "+sourceIP+":"+tcp.source()+","+destinationIP+":"+tcp.destination()+"\n", null);
					}
					else if(packet.hasHeader(udp))
					{
						// Printing the source and destination address with port numbers
						txtpnHello.getStyledDocument().insertString(txtpnHello.getStyledDocument().getLength(), counter+"->UDP  "+sourceIP+":"+udp.source()+","+destinationIP+":"+udp.destination()+"\n", null);						
					}
					else if(packet.hasHeader(icmp))
					{
						//Printing the source and destination address with port numbers
						txtpnHello.getStyledDocument().insertString(txtpnHello.getStyledDocument().getLength(), counter+"->ICMP  "+sourceIP+","+destinationIP+"\n", null);
					}
					else
					{
						//Printing the source and destination address
						txtpnHello.getStyledDocument().insertString(txtpnHello.getStyledDocument().getLength(), counter+"->"+sourceIP+","+destinationIP+"\n", null);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}while(pcap.nextEx(packet) != Pcap.NEXT_EX_EOF);
		
		
		//we enter the loop and capture the 100 packets here.You can  capture any number of packets just by changing the first argument to pcap.loop() function below
		//pcap.loop(100, jpacketHandler, "jnetpcap rocks!");
		
		//we enter the loop and capture INFINITE packets here.You can  capture any number of packets just by changing the first argument to pcap.loop() function below
		//pcap.loop(Pcap.LOOP_INFINITE, jpacketHandler, null);
		
		return counterL;
	}

	//to oepn the file
	@Override
	public void open() {
		
		//File
		String ofile = file.getAbsolutePath();
		
		//Openning the file
		pcap = Pcap.openOffline(ofile, errbuf);
		if (pcap == null) {
			txtpnHello.setText("Error while opening file for capture, error is "+errbuf.toString());
		}
		
		txtpnHello.setText("File : "+file.getName()+" opened Successfuly\n\n");
		
	}

	@Override
	public void quit() {
		try{
			//Close the pcap
			pcap.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}

