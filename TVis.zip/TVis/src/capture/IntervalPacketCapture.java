package capture;

import java.util.LinkedList;

import org.jnetpcap.packet.PcapPacket;

public interface IntervalPacketCapture {
	public long capture(LinkedList<PcapPacket> allPackets);

	public void open();

	public void quit();
}
