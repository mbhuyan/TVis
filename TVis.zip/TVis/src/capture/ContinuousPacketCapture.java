package capture;

import java.awt.Choice;
import java.io.File;
import java.util.LinkedList;

import javax.swing.JTextPane;

import org.jfree.chart.ChartPanel;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jnetpcap.packet.PcapPacket;

import graph.LineGraph;


public class ContinuousPacketCapture implements Runnable{
	
	private IntervalPacketCapture packet = null;		//Object that handels Pcap
	private File file = null;					//Pcap file for offline
	private JTextPane txtpnHello = null;
	private ChartPanel chartPanel1 = null;
	private boolean ch = true;					//For looping until stopped
	private DefaultCategoryDataset data = null;	//Dataset for the Main graph
	
	//for the analyzing part
	private LinkedList<LinkedList<PcapPacket>> allTimePackets;
	
	//Constructor in case of Online Packet Capturing
	public ContinuousPacketCapture(LinkedList<LinkedList<PcapPacket>> allTimePackets, Choice choice, JTextPane txtpnHello, ChartPanel chartPanel1) {
		this.file = null;
		this.allTimePackets = allTimePackets;
		this.txtpnHello = txtpnHello;
		this.chartPanel1 = chartPanel1;
        this.data = new DefaultCategoryDataset();
		this.packet = new PacketCaptureOnline(choice, txtpnHello);
	}
	
	//Constructor in case of Offline Packet Capturing
	public ContinuousPacketCapture(LinkedList<LinkedList<PcapPacket>> allTimePackets, File file, JTextPane txtpnHello, ChartPanel chartPanel1) {
		this.file = file;
		this.allTimePackets = allTimePackets;
		this.txtpnHello = txtpnHello;
		this.chartPanel1 = chartPanel1;
		this.data = new DefaultCategoryDataset();
		this.packet = new PacketCaptureOffline(file,txtpnHello);
	}

	//For Multiplexing 
	@Override
	public void run() {
		data.clear();
		if(file == null)
		{
			online();
		}
		else
		{
			offline();
		}
	}
	
	//Online
	private void online()
	{
		ch = true;
		packet.open();
		txtpnHello.setText("Device opened Successfuly\n\n");
		data.addValue(0, "packets", ""+0);
		for(int time = 5; ch && time<300; time = time+5)
		{
			LinkedList<PcapPacket> allPackets = new LinkedList<PcapPacket>();
			long num = packet.capture(allPackets);
			data.addValue(num, "packets", ""+time);
			new LineGraph(chartPanel1,"Packets Received",data,"Time (in Seconds)","Number of Packets");
			allTimePackets.add(allPackets);
		}
		
	}
	
	//Offline
	private void offline()
	{
		packet.open();
		int time = 5;
		data.addValue(0, "packets", ""+0);
		while(true)
		{
			LinkedList<PcapPacket> allPackets = new LinkedList<PcapPacket>();
			long num = packet.capture(allPackets);
			if(num == -1)
			{
				break;
			}
			data.addValue(num, "packets", ""+time);
			new LineGraph(chartPanel1,"Main Graph",data,"Time (in Seconds)","Number of Packets");
			allTimePackets.add(allPackets);
			time = time+5;
		}
	}

	public void quit() {
		ch = false;
		packet.quit();
	}
}
