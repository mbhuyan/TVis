import mode.Online;

public class Main {

	public static void main(String[] args) {
		Online.main();
	}

}
