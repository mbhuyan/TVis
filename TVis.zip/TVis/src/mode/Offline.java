package mode;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.LinkedList;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jnetpcap.packet.PcapPacket;

import capture.ContinuousPacketCapture;
import graph.VisualGraph;

public class Offline {

	//Declaration
	private JFrame frame;
	private JButton btnNewButton;
	private JButton btnNewButton2;
	private JPanel panel;
	private JMenuItem mntmAbout;
	private JMenuItem mntmOpen;
	private JMenu mnHelp;
	private JMenuItem mntmExit;
	private JMenuItem mntmNew;
	private JMenu mnFile;
	private JTextPane txtpnHello;
	private Thread t;
	private Runnable r;
	private JScrollPane scrollPane;
	private ChartPanel chartPanel;
	private JFreeChart chart;
	private JPanel panel_1;
	private JMenuBar menuBar;
	private JFileChooser fileChooser;
	private File file;
	
	//for the analyzing part
	private LinkedList<LinkedList<PcapPacket>> allTimePackets;

	/**
	 * Launch the application.
	 */
	public static void main(File file) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Offline window = new Offline(file);
					window.update();
					window.frame.setVisible(true);
					window.frame.setMinimumSize(new Dimension(window.frame.getWidth()/2, window.frame.getHeight()/2));
					window.update();
					window.exe();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Offline(File file) {
		this.file = file;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		//Initializing the list
		allTimePackets = new LinkedList<LinkedList<PcapPacket>>();
		
		//Frame Creation
		frame = new JFrame();
		frame.setTitle("KUD-Vis: "+file.getAbsolutePath());
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.getContentPane().setLayout(null);
		frame.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent arg0) {
				update();
			}
		});
		
		
		//Panel For Display
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setLayout(null);
		frame.getContentPane().add(panel);
		scrollPane = new JScrollPane();		//For a scrollable panel
		panel.add(scrollPane);
		txtpnHello = new JTextPane();		//Display all the packets
		txtpnHello.setEditable(false);
		scrollPane.setViewportView(txtpnHello);
		
		//Graph Side main Panel
		panel_1 = new JPanel();
		panel_1.setLayout(null);
		frame.getContentPane().add(panel_1);
		
		//The Main Graph
		chartPanel = new ChartPanel(chart);	//For Bar Graph
		panel_1.add(chartPanel);
		btnNewButton = new JButton("Analyse");	//button for detail analysing
		panel_1.add(btnNewButton);
		btnNewButton2 = new JButton("Visualize");	//button for detail Visualize
		panel_1.add(btnNewButton2);

		r = new ContinuousPacketCapture(allTimePackets, file,txtpnHello,chartPanel);
		
		//Menu Bar
		menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		mnFile = new JMenu("File");
		menuBar.add(mnFile);
		mntmNew = new JMenuItem("Online");
		mnFile.add(mntmNew);
		mntmOpen = new JMenuItem("Open");
		mnFile.add(mntmOpen);
		mntmExit = new JMenuItem("Exit");
		mnFile.add(mntmExit);
		mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);
		mntmAbout = new JMenuItem("About");
		mnHelp.add(mntmAbout);
		
		// Action to be performed on closing
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent arg0) {
				if(t != null)
				{
					((ContinuousPacketCapture)r).quit();
				}
			}
		});
		
		//Action to be performed on changing the size of the window
		frame.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent arg0) {
				update();
			}
		});
		
		//Action to performed on clicking Analyze button
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AnalyseWindow.main(allTimePackets,btnNewButton);
				btnNewButton.setEnabled(false);
			}
		});
		
		//Action to performed on clicking Visualize button
		btnNewButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				VisualGraph.main(allTimePackets,btnNewButton2);
				btnNewButton2.setEnabled(false);
			}
		});
		
		//Action of Menu Bar -> File -> New
		mntmNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Online.main();
			}
		});
		
		//Action of Menu -> File -> Exit
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				close();
			}
		});
		
		//Action of Menu -> File -> Open
		mntmOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        fileChooser = new JFileChooser(new File("."));
		        fileChooser.setFileFilter(new MyFilter());
	            int returnVal = fileChooser.showOpenDialog(menuBar);
	            if (returnVal == JFileChooser.APPROVE_OPTION) {
	            	file = fileChooser.getSelectedFile();
	            	Offline.main(file);
	            }
			}
		});
		
		
		//Action of Menu -> Help -> About
		mntmAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(frame,
					    "KUD-Vis\nVersion 1.0\n"
					    + "Developed by Abhishek Kalwar\n"
					    + "Major Project",
					    "A plain message",
					    JOptionPane.PLAIN_MESSAGE);
			}
		});
		
	}
	
	public void exe()
	{
		t = new Thread(r);
		t.start();
	}
	
	private void update(){
		panel.setBounds(2, 0, frame.getWidth()/2-8, frame.getHeight()-70);
		scrollPane.setBounds(2, 5, panel.getWidth()-4, panel.getHeight()-10);
		panel_1.setBounds(panel.getWidth(), 0, frame.getWidth()/2-8, frame.getHeight()-70);
		chartPanel.setBounds(5, 0, panel_1.getWidth()-8, panel_1.getHeight()-45);
		btnNewButton.setBounds(7, chartPanel.getHeight(), panel_1.getWidth()/2-7, 40);
		btnNewButton2.setBounds(btnNewButton.getWidth()+5, chartPanel.getHeight(), panel_1.getWidth()/2-7, 40);
	}
	
	private void close()
	{
		this.frame.dispose();
	}

}
