package mode;

import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Paint;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.LegendItem;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jnetpcap.packet.PcapPacket;

import analyse.Analyse;
import analyse.DestinationIP;
import analyse.Protocols;
import analyse.SourceIP;
import analyse.TCPPort;
import analyse.UDPPort;
import analyse.UniqueIP;
import graph.LineGraph;

public class AnalyseWindow {

	private JButton btnNewButton; // to enable Analyse button again on closing
	private JFrame frame;
	private JToolBar toolBar;
	private Choice  choice;
	Choice choice_1;
	private JPanel panel_1;
	private ChartPanel panel; 
	private LinkedList<LinkedList<PcapPacket>> allTimePackets;
	private Analyse a = null;
	private JPanel panel_2;
	private JScrollPane scrollPane;

	/**
	 * Launch the application.
	 * @param btnNewButton 
	 */
	public static void main(LinkedList<LinkedList<PcapPacket>> allTimePackets, JButton btnNewButton) {
		AnalyseWindow window = new AnalyseWindow(allTimePackets,btnNewButton);
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					window.update();
					window.frame.setVisible(true);
					window.frame.setMinimumSize(new Dimension(window.frame.getWidth()/2, window.frame.getHeight()/2));
					window.update();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AnalyseWindow(LinkedList<LinkedList<PcapPacket>> allTimePackets, JButton btnNewButton) {
		this.allTimePackets = allTimePackets;
		this.btnNewButton = btnNewButton;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		frame = new JFrame();
		frame.setTitle("Analyse");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.getContentPane().setLayout(null);
		
		toolBar = new JToolBar();
		toolBar.setFloatable(false);
		toolBar.setRollover(true);
		toolBar.setBounds(53, 0, 87, 16);
		frame.getContentPane().add(toolBar);
		
		choice = new Choice();
		toolBar.add(choice);
		
		choice_1 = new Choice();
		toolBar.add(choice_1,BorderLayout.NORTH);
		choice_1.setVisible(false);
		
		panel_1 = new JPanel();
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		panel = new ChartPanel(null);
		panel.setBounds(0, 0, 0, 10);
		panel_1.add(panel);
		
		panel_2 = new JPanel();
		panel_2.setBackground(Color.WHITE);
		
		scrollPane = new JScrollPane(panel_2);
		scrollPane.setBounds(0, 10, 0, 23);
		panel_1.add(scrollPane);
		
		
		choice.addItem("Choose The graph to view");
		choice.addItem("Unique IP");
		choice.addItem("Source IP");
		choice.addItem("Destination IP");
		choice.addItem("Unique TCP port");
		choice.addItem("Unique UDP port");
		choice.addItem("Protocol");
		
		
		//Action for the choice
		choice.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				panel_2.removeAll();
				int ch = choice.getSelectedIndex();
				String title = "",xAxis = "",yAxis = "";
				switch(ch)
				{
				case 1:
					a = new UniqueIP();
					title = "Number of Unique IP ";
					xAxis = "Time (in Seconds)";
					yAxis = "Number of IP Address";
					break;
				case 2:
					a = new SourceIP(choice_1);
					break;
				case 3:
					a = new DestinationIP(choice_1);
					break;
				case 4:
					a = new TCPPort();
					title = "Unique TCP Ports";
					xAxis = "Time (in Seconds)";
					yAxis = "Number of TCP Ports";
					break;
				case 5:
					a = new UDPPort();
					title = "Unique UDP Ports";
					xAxis = "Time (in Seconds)";
					yAxis = "Number of UDP Ports";
					break;
				case 6:
					a = new Protocols();
					title = "Protocols";
					xAxis = "Time (in Seconds)";
					yAxis = "Number of packets";
					break;
				default:
					panel.setChart(null);
					a = null;
					break;
				}
				if(a != null)
				{
					if(ch == 2 || ch == 3)
					{
						choice_1.setVisible(true);
						update();
						a.execute(allTimePackets);
					}
					else
					{
						choice_1.setVisible(false);
						update();
						DefaultCategoryDataset data = a.execute(allTimePackets);
						new LineGraph(panel,title,data,xAxis,yAxis);
						panel_2.removeAll();
						@SuppressWarnings("rawtypes")
						Iterator iterator = panel.getChart().getPlot().getLegendItems().iterator();
					    while (iterator.hasNext()) {
					        LegendItem item = (LegendItem) iterator.next();
					        JLabel label = new JLabel(item.getLabel());
					        label.setIcon(new MyIcon(item.getFillPaint()));
					        panel_2.add(label);
					    }
					    panel_2.repaint();
					    update();
					}
				}
				else
				{
					choice_1.setVisible(false);
					update();
				}
			}
		});
		
		
		//Action for IP to IP
		choice_1.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				DefaultCategoryDataset data = a.getIPGraph();
				new LineGraph(panel,choice_1.getSelectedItem(),data,"Time (in Seconds)","Number of packets");
				panel_2.removeAll();
				@SuppressWarnings("rawtypes")
				Iterator iterator = panel.getChart().getPlot().getLegendItems().iterator();
			    while (iterator.hasNext()) {
			        LegendItem item = (LegendItem) iterator.next();
			        JLabel label = new JLabel(item.getLabel());
			        label.setIcon(new MyIcon(item.getFillPaint()));
			        panel_2.add(label);
			    }
			    panel_2.repaint();
			    update();
			}
		});
		
		
		// Action to be performed on closing
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent arg0) {
				btnNewButton.setEnabled(true);
			}
		});
		
		//Action to be performed on changing the size of the window
		frame.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent arg0) {
				update();
			}
		});
	}
	
	private void update(){
		toolBar.setBounds(0, 0, frame.getWidth()-15, 40);
		toolBar.updateUI();
		panel_1.setBounds(2, 40, frame.getWidth()-8, frame.getHeight()-90);
		panel.setBounds(0, 0, panel_1.getWidth()-10, panel_1.getHeight()-43);
		scrollPane.setBounds(0, panel_1.getHeight()-40, panel_1.getWidth()-15, 40);
	}
	
	private class MyIcon implements Icon
	{
		private Paint f;
	    public MyIcon(Paint fillPaint) {
			// TODO Auto-generated constructor stub
	    	this.f = fillPaint;
		}

		public int getIconHeight() { return 3; }
	  
	    public int getIconWidth() { return 10; }
	  
	    public void paintIcon(Component c, Graphics g, int x, int y)
	    {
	        // store the old color; I like to leave Graphics as I receive them
	        Color old = g.getColor();
	        g.setColor((Color) f);
	        g.fillRect(x, y, getIconWidth(), getIconHeight());
	        g.setColor(old);
	    }
	}
}
