package mode;
import java.awt.Button;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.LinkedList;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jnetpcap.packet.PcapPacket;

import capture.ContinuousPacketCapture;
import graph.VisualGraph;

public class Online {

	//Declaration
	private JFrame frame;
	private JToolBar toolBar;
	private Button button;
	private Button button_1;
	private JButton btnNewButton;
	private JButton btnNewButton2;
	private JPanel panel;
	private JMenuItem mntmAbout;
	private JMenuItem mntmOpen;
	private JMenu mnHelp;
	private JMenuItem mntmExit;
	private JMenuItem mntmNew;
	private JMenu mnFile;
	private Choice choice;
	private JLabel lblNewLabel;
	private JTextPane txtpnHello;
	private Thread t;
	private Runnable r;
	private JScrollPane scrollPane;
	private JLayeredPane layeredPane;
	private ChartPanel chartPanel1;
	private ChartPanel chartPanel2;
	private JFreeChart chart;
	private JPanel panel_1;
	private JMenuBar menuBar;
	private JFileChooser fileChooser;
	private File file;
	
	//for the analyzing part
	private LinkedList<LinkedList<PcapPacket>> allTimePackets;

	/**
	 * Launch the application.
	 */
	public static void main() {
		try {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						Online window = new Online();
						window.update();
						window.frame.setVisible(true);
						window.frame.setMinimumSize(new Dimension(window.frame.getWidth()/2, window.frame.getHeight()/2));
						window.update();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the application.
	 */
	public Online() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		//Initializing the list
		allTimePackets = new LinkedList<LinkedList<PcapPacket>>();
		
		//Frame Creation
		frame = new JFrame();
		frame.setTitle("KUD-Vis: Online");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.getContentPane().setLayout(null);
		
		//ToolBar (Start and Stop)
		toolBar = new JToolBar();
		button = new Button("Start");  	//Start Button
		button_1 = new Button("Stop");	//Stop Button
		toolBar.setFloatable(false);
		toolBar.setRollover(true);
		frame.getContentPane().add(toolBar);
		toolBar.add(button);
		button_1.setEnabled(false);
		toolBar.add(button_1);
		
		//Panel For Display
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setLayout(null);
		frame.getContentPane().add(panel);
		choice = new Choice();		//To View List of devices
		choice.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 18));
		choice.setVisible(false);
		panel.add(choice);
		lblNewLabel = new JLabel("Choose the one device from below list of devices"); //To Display message
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setVisible(false);
		lblNewLabel.setAlignmentY(Component.TOP_ALIGNMENT);
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblNewLabel);
		scrollPane = new JScrollPane();		//For a scrollable panel
		panel.add(scrollPane);
		txtpnHello = new JTextPane();		//Display all the packets
		txtpnHello.setEditable(false);
		scrollPane.setViewportView(txtpnHello);
		
		//Graph Side main Panel
		panel_1 = new JPanel();
		panel_1.setLayout(null);
		frame.getContentPane().add(panel_1);
		
		//The Main Graph
		chartPanel1 = new ChartPanel(chart);	//For Line Graph
		chartPanel1.setVisible(true);
		chartPanel2 = new ChartPanel(chart);	//For Bar Graph
		chartPanel1.setOpaque(false);			//Making Line graph panel transperant
		chartPanel2.setOpaque(false);			//Making Bar graph panel transperant
		layeredPane = new JLayeredPane();		//for Layered Panel
		layeredPane.setLayout(null);
		layeredPane.add(chartPanel1);
		layeredPane.add(chartPanel2);
		layeredPane.setLayer(chartPanel1, 2);	//top layer as line chart
		layeredPane.setLayer(chartPanel2, 0);	//bottom layer as bar chart
		panel_1.add(layeredPane);
		btnNewButton = new JButton("Analyse");	//button for detail analysing
		btnNewButton.setEnabled(false);
		panel_1.add(btnNewButton);
		btnNewButton2 = new JButton("Visualize");	//button for detail Visualize
		btnNewButton2.setEnabled(false);
		panel_1.add(btnNewButton2);
		
		
		
		//Menu Bar
		menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		mnFile = new JMenu("File");
		menuBar.add(mnFile);
		mntmNew = new JMenuItem("Online");
		mnFile.add(mntmNew);
		mntmOpen = new JMenuItem("Open");
		mnFile.add(mntmOpen);
		mntmExit = new JMenuItem("Exit");
		mnFile.add(mntmExit);
		mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);
		mntmAbout = new JMenuItem("About");
		mnHelp.add(mntmAbout);
		
		// Action to be performed on closing
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent arg0) {
				if(t != null)
				{
					((ContinuousPacketCapture)r).quit();
				}
			}
		});
		
		//Action to be performed on changing the size of the window
		frame.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent arg0) {
				update();
			}
		});

		// Start button action
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				button.setEnabled(false);
				button_1.setEnabled(true);
				lblNewLabel.setVisible(true);
				btnNewButton.setEnabled(false);
				btnNewButton2.setEnabled(false);
				r = new ContinuousPacketCapture(allTimePackets,choice,txtpnHello,chartPanel1);
			}
		});
		
		
		// Stop button action
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				button.setEnabled(true);
				button_1.setEnabled(false);
				((ContinuousPacketCapture)r).quit();
				btnNewButton.setEnabled(true);
				btnNewButton2.setEnabled(true);
			}
		});
		
		// Choice action
		choice.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				if(!button.isEnabled())
				{
					choice.setEnabled(false);
					if(t!=null)
					{
						((ContinuousPacketCapture)r).quit();
						try {
							t.join();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					txtpnHello.setText("");
					chartPanel1.setChart(null);
					allTimePackets.clear();
					t = new Thread(r);
					t.start();
				}
			}
		});
		
		//Action to performed on clicking Analyze button
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AnalyseWindow.main(allTimePackets,btnNewButton);
				btnNewButton.setEnabled(false);
			}
		});
		
		//Action to performed on clicking Visualize button
		btnNewButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				VisualGraph.main(allTimePackets,btnNewButton2);
				btnNewButton2.setEnabled(false);
			}
		});
		
		//Action of Menu Bar -> File -> New
		mntmNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Online.main();
			}
		});
		
		//Action of Menu -> File -> Exit
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				close();
			}
		});
		
		//Action of Menu -> File -> Open
		mntmOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        fileChooser = new JFileChooser(new File("."));
		        fileChooser.setFileFilter(new MyFilter());
	            int returnVal = fileChooser.showOpenDialog(menuBar);
	            if (returnVal == JFileChooser.APPROVE_OPTION) {
	            	file = fileChooser.getSelectedFile();
	            	Offline.main(file);
	            }
			}
		});
		
		
		//Action of Menu -> Help -> About
		mntmAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(frame,
					    "KUD-Vis\nVersion 1.0\n"
					    + "Developed by Abhishek Kalwar\n"
					    + "Major Project",
					    "A plain message",
					    JOptionPane.PLAIN_MESSAGE);
			}
		});
		
	}
	
	private void update(){
		toolBar.setBounds(0, 0, frame.getWidth()-14, 40);
		toolBar.updateUI();
		panel.setBounds(2, 40, frame.getWidth()/2-8, frame.getHeight()-110);
		choice.setBounds(2, 20, panel.getWidth()-5, 20);
		lblNewLabel.setBounds(2, 0, panel.getWidth()-5, 20 );
		scrollPane.setBounds(2, 42, panel.getWidth()-4, panel.getHeight()-45);
		panel_1.setBounds(panel.getWidth(), 40, frame.getWidth()/2-8, frame.getHeight()-110);
		layeredPane.setBounds(5, 0, panel_1.getWidth()-8, panel_1.getHeight()-45);
		chartPanel1.setBounds(0, 0, layeredPane.getWidth(), layeredPane.getHeight()-10);
		chartPanel2.setBounds(0, 0, layeredPane.getWidth(), layeredPane.getHeight()-10);
		btnNewButton.setBounds(7, layeredPane.getHeight(), panel_1.getWidth()/2-7, 40);
		btnNewButton2.setBounds(btnNewButton.getWidth()+5, layeredPane.getHeight(), panel_1.getWidth()/2-7, 40);
	}
	
	private void close()
	{
		this.frame.dispose();
	}

}
