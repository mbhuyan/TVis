package mode;

import java.io.File;
import javax.swing.filechooser.FileFilter;

class MyFilter extends FileFilter {
	
	public String getDescription() {
		return "*.pcap";
	}

	@Override
	public boolean accept(File arg0) {
	    if (arg0.isDirectory()) {
	        return true;
	    }
		String filename = arg0.getName();
		return filename.endsWith(".pcap");
	}
}
