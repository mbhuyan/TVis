package graph;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.title.LegendTitle;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class LineGraph {

	private LegendTitle legend;
	
	public LineGraph(ChartPanel panel, String title,DefaultCategoryDataset dataset,String xAxis, String yAxis)
	{
		XYDataset data = convertToXYDataset(dataset);
		JFreeChart chart = ChartFactory.createXYLineChart(
		         title,
		         xAxis,
		         yAxis,
		         data,
		         PlotOrientation.VERTICAL,
		         false,false,false);
		XYPlot xy = chart.getXYPlot();
		NumberAxis domain = (NumberAxis) xy.getDomainAxis();
		domain.setVerticalTickLabels(true);
		domain.setTickUnit(new NumberTickUnit(5));
		legend = chart.getLegend();
		panel.setChart(chart);
		panel.setMouseZoomable(false);
	}

	private XYDataset convertToXYDataset(DefaultCategoryDataset dataset) {
		int a = dataset.getRowCount();
		int b = dataset.getColumnCount();
		XYSeriesCollection data = new XYSeriesCollection( );
		for(int i = 0; i<a; i++)
		{
			XYSeries temp = new XYSeries( dataset.getRowKey(i) );
			for(int j = 0, k = 0; j<b; j++)
			{
				double t = Double.parseDouble(dataset.getColumnKey(j).toString());
				Number tempValue = dataset.getValue(i, j);
				if(tempValue == null)
					tempValue = 0;
				while(t != k)
				{
					temp.add(k, 0);
					k = k+5;
				}
				temp.add(t, tempValue);
				k = k+5;
			}
			data.addSeries(temp);
		}
		return data;
	}
	
	public LegendTitle getLegend()
	{
		return legend;
	}
}
