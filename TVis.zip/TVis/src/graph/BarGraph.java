package graph;

import java.awt.Color;
import java.awt.GradientPaint;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class BarGraph
{
	public BarGraph(ChartPanel panel, String title,DefaultCategoryDataset data,String xAxis, String yAxis)
	{
		
		JFreeChart chart = ChartFactory.createBarChart(
	            title,
	            xAxis,
	            yAxis,
	            data,
	            PlotOrientation.VERTICAL,
	            true,false,false);
		// then customise it a little...
		chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 1000, 0, Color.blue));
		chart.getCategoryPlot().getDomainAxis().setCategoryLabelPositions(CategoryLabelPositions.UP_90);
		panel.setChart(chart);
		panel.setMouseZoomable(false);
	}
}