package graph;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.Paint;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
//To get the execution time uncomment this
//import javax.swing.JOptionPane;
import javax.swing.JPanel;

import org.apache.commons.collections15.Transformer;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.protocol.network.Ip4;

import edu.uci.ics.jung.algorithms.layout.FRLayout;
import edu.uci.ics.jung.algorithms.layout.util.RandomLocationTransformer;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;
import edu.uci.ics.jung.graph.util.EdgeType;
import edu.uci.ics.jung.visualization.GraphZoomScrollPane;
import edu.uci.ics.jung.visualization.LayeredIcon;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.control.CrossoverScalingControl;
import edu.uci.ics.jung.visualization.control.DefaultModalGraphMouse;
import edu.uci.ics.jung.visualization.control.ScalingControl;
import edu.uci.ics.jung.visualization.decorators.DefaultVertexIconTransformer;
import edu.uci.ics.jung.visualization.decorators.EllipseVertexShapeTransformer;
import edu.uci.ics.jung.visualization.decorators.PickableEdgePaintTransformer;
import edu.uci.ics.jung.visualization.decorators.PickableVertexPaintTransformer;
import edu.uci.ics.jung.visualization.decorators.ToStringLabeller;
import edu.uci.ics.jung.visualization.decorators.VertexIconShapeTransformer;
import edu.uci.ics.jung.visualization.picking.PickedState;
import edu.uci.ics.jung.visualization.renderers.Checkmark;
import edu.uci.ics.jung.visualization.renderers.DefaultEdgeLabelRenderer;
import edu.uci.ics.jung.visualization.renderers.DefaultVertexLabelRenderer;

public class VisualGraph {

	private JFrame frame;
	private JButton btnNewButton; // to enable Visualize button again on closing
	private LinkedList<LinkedList<PcapPacket>> allTimePackets;
	private HashMap<Number,String> mapVertex;
	private HashMap<Number,HashSet<Number>> mapEdges;
	
	
	private int VERTEX_COUNT;

	/**
     * the graph
     */
    UndirectedSparseGraph<Number, Number> graph;

    /**
     * the visual component and renderer for the graph
     */
    VisualizationViewer<Number, Number> vv;

	/**
	 * Launch the application.
	 */
	public static void main(LinkedList<LinkedList<PcapPacket>> allTimePackets, JButton btnNewButton) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//To get the execution time uncomment this
					//final long start = System.currentTimeMillis();
					
					VisualGraph window = new VisualGraph(allTimePackets,btnNewButton);
					window.frame.setVisible(true);
					
					//To get the execution time uncomment this
					/*
					JOptionPane.showMessageDialog(window.frame,
						    "Time = "+(System.currentTimeMillis()-start)+" (in milli seconds)",
						    "Execution time for graph",
						    JOptionPane.PLAIN_MESSAGE);
					 */
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	

	/**
	 * Create the application.
	 */
	public VisualGraph(LinkedList<LinkedList<PcapPacket>> allTimePackets, JButton btnNewButton) {
		this.allTimePackets = allTimePackets;
		this.btnNewButton = btnNewButton;
		mapVertex = new HashMap<Number,String>();
		mapEdges = new HashMap<Number,HashSet<Number>>();
		initialize();
        
        // create a simple graph for the demo
        graph = new UndirectedSparseGraph<Number,Number>();
        
        /**
         * Call to get all devices with there ip 
         * and get connections between them
         */
        mapDevices();
        
        /**
         * create vertices
         */
        addVertex();
        
        /**
         * create edges
         */
        addEdges();
        
        /**
         *  a Map for the Icons
         */
        Map<Number,Icon> iconMap = new HashMap<Number,Icon>();
        for(int i=0; i<VERTEX_COUNT; i++) {
            String name = "img/img.png";
            try {
                Icon icon = 
                    new LayeredIcon(new ImageIcon(name).getImage());
                iconMap.put(i, icon);
            } catch(Exception ex) {
            	ex.printStackTrace();
            }
        }
        
        FRLayout<Number, Number> layout = new FRLayout<Number, Number>(graph);
        layout.setInitializer(new RandomLocationTransformer<Number>(new Dimension(400,400), 0));
        vv =  new VisualizationViewer<Number, Number>(layout, new Dimension(400,400));

        Transformer<Number,Paint> vpf = 
            new PickableVertexPaintTransformer<Number>(vv.getPickedVertexState(), Color.white, Color.yellow);
        vv.getRenderContext().setVertexFillPaintTransformer(vpf);
        vv.getRenderContext().setEdgeDrawPaintTransformer(new PickableEdgePaintTransformer<Number>(vv.getPickedEdgeState(), Color.black, Color.cyan));

        vv.setBackground(Color.white);
        
        
        final Transformer<Number,String> vertexStringerImpl = 
            new VertexStringerImpl<Number,String>(mapVertex);
        vv.getRenderContext().setVertexLabelTransformer(vertexStringerImpl);
        vv.getRenderContext().setVertexLabelRenderer(new DefaultVertexLabelRenderer(Color.cyan));
        vv.getRenderContext().setEdgeLabelRenderer(new DefaultEdgeLabelRenderer(Color.cyan));
        
        final VertexIconShapeTransformer<Number> vertexIconShapeTransformer =
            new VertexIconShapeTransformer<Number>(new EllipseVertexShapeTransformer<Number>());
        
        final DefaultVertexIconTransformer<Number> vertexIconTransformer =
        	new DefaultVertexIconTransformer<Number>();
        
        vertexIconShapeTransformer.setIconMap(iconMap);
        vertexIconTransformer.setIconMap(iconMap);
        
        vv.getRenderContext().setVertexShapeTransformer(vertexIconShapeTransformer);
        vv.getRenderContext().setVertexIconTransformer(vertexIconTransformer);
        
        
        PickedState<Number> ps = vv.getPickedVertexState();
        ps.addItemListener(new PickWithIconListener<Number>(vertexIconTransformer));
        
       
        /**
         *  add a listener for ToolTips
         */
        vv.setVertexToolTipTransformer(new ToStringLabeller<Number>());
        
        Container content = frame.getContentPane();
        final GraphZoomScrollPane panel = new GraphZoomScrollPane(vv);
        content.add(panel);
        
        final DefaultModalGraphMouse<Number,Number> graphMouse = new DefaultModalGraphMouse<Number,Number>();
        vv.setGraphMouse(graphMouse);
        vv.addKeyListener(graphMouse.getModeKeyListener());
        final ScalingControl scaler = new CrossoverScalingControl();

        JButton plus = new JButton("+");
        plus.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                scaler.scale(vv, 1.1f, vv.getCenter());
            }
        });
        JButton minus = new JButton("-");
        minus.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                scaler.scale(vv, 1/1.1f, vv.getCenter());
            }
        });
        
        JComboBox<?> modeBox = graphMouse.getModeComboBox();
        JPanel modePanel = new JPanel();
        modePanel.setBorder(BorderFactory.createTitledBorder("Mouse Mode"));
        modePanel.add(modeBox);
        
        JPanel scaleGrid = new JPanel(new GridLayout(1,0));
        scaleGrid.setBorder(BorderFactory.createTitledBorder("Zoom"));
        JPanel controls = new JPanel();
        scaleGrid.add(plus);
        scaleGrid.add(minus);
        controls.add(scaleGrid);

        controls.add(modePanel);
        content.add(controls, BorderLayout.SOUTH);
    }
	
	
	private void addEdges() {
		int k = 0;
		for(Number i : mapEdges.keySet())
		{
			for(Number j : mapEdges.get(i))
			{
				graph.addEdge(k++, i, j, EdgeType.UNDIRECTED);
			}
		}
	}


	/**
	 * Finding the devices and adding them to a map    
	 */
    private void mapDevices() {
    	HashSet<String> unique = new HashSet<String>();
    	HashMap<String,HashSet<String>> tempEdgeMap = new HashMap<String,HashSet<String>>();
		Ip4 ip = new Ip4();
		for(LinkedList<PcapPacket> l1 : allTimePackets)
		{
			for(PcapPacket l2 : l1)
			{
				if(l2.hasHeader(ip))
				{
					String temps = org.jnetpcap.packet.format.FormatUtils.ip(ip.source());
					String tempd = org.jnetpcap.packet.format.FormatUtils.ip(ip.destination());
					unique.add(temps);
					unique.add(tempd);
					tempEdgeMap.putIfAbsent(temps, new HashSet<String>());
					tempEdgeMap.get(temps).add(tempd);
				}
			}
		}
		VERTEX_COUNT = unique.size();
    	int i = 0;
		LinkedList<String> temp = new LinkedList<String>(unique);
		for(String l:unique)
		{
			mapVertex.putIfAbsent(i, l);
			if(tempEdgeMap.containsKey(l))
			{
				mapEdges.putIfAbsent(i, new HashSet<Number>());
				HashSet<Number> innerLoop = mapEdges.get(i);
				for(String k : tempEdgeMap.get(l))
				{
					innerLoop.add(temp.indexOf(k));
				}
			}
			i++;
		}
	}
    
    

	/**
     * When Vertices are picked, add a checkmark icon to the imager.
     * Remove the icon when a Vertex is unpicked
     *
     */
    public static class PickWithIconListener<V> implements ItemListener {
        DefaultVertexIconTransformer<V> imager;
        Icon checked;
        
        public PickWithIconListener(DefaultVertexIconTransformer<V> imager) {
            this.imager = imager;
            checked = new Checkmark();
        }

        @SuppressWarnings("unchecked")
		public void itemStateChanged(ItemEvent e) {
            Icon icon = imager.transform((V)e.getItem());
            if(icon != null && icon instanceof LayeredIcon) {
                if(e.getStateChange() == ItemEvent.SELECTED) {
                    ((LayeredIcon)icon).add(checked);
                } else {
                    ((LayeredIcon)icon).remove(checked);
                }
            }
        }
    }
    
    /**
     * A simple implementation of VertexStringer that
     * gets Vertex labels from a Map  
     */
    public static class VertexStringerImpl<V,S> implements Transformer<V,String> {
        
        Map<V,String> map = new HashMap<V,String>();
        
        boolean enabled = true;
        
        public VertexStringerImpl(Map<V,String> map) {
            this.map = map;
        }
        
        public String transform(V v) {
            if(isEnabled()) {
                return map.get(v);
            } else {
                return "";
            }
        }
        
        /**
         * @return Returns the enabled.
         */
        public boolean isEnabled() {
            return enabled;
        }
        
        /**
         * @param enabled The enabled to set.
         */
        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
    }
    
    /**
     * create some vertices
     * @param count how many to create
     * @return the Vertices in an array
     */
    private void addVertex() {
        for (int i = 0; i < VERTEX_COUNT; i++) {
            graph.addVertex(i);
        }
    }

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		frame = new JFrame();
		frame.setTitle("Analyse");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		
		/**
		 *  Action to be performed on closing
		 */
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent arg0) {
				btnNewButton.setEnabled(true);
			}
		});
	}

}
