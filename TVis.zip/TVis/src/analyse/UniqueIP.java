package analyse;

import java.util.HashSet;
import java.util.LinkedList;

import org.jfree.data.category.DefaultCategoryDataset;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.protocol.network.Ip4;

public class UniqueIP implements Analyse{
	
	@Override
	 public DefaultCategoryDataset execute(LinkedList<LinkedList<PcapPacket>> allTimePackets)
	{
		Ip4 ip = new Ip4();
		DefaultCategoryDataset data = new DefaultCategoryDataset();
		data.addValue(0, "Overall", "0");
		data.addValue(0, "Source IP address", "0");
		data.addValue(0, "Destination IP address", "0");
		int t = 5;
		for(LinkedList<PcapPacket> l1 : allTimePackets)
		{
			HashSet<String> uniqueIP = new HashSet<String>();
			HashSet<String> uniqueSourceIP = new HashSet<String>();
			HashSet<String> uniqueDestinationIP = new HashSet<String>();
			for(PcapPacket l2 : l1)
			{
				if(l2.hasHeader(ip))
				{
					String temps = org.jnetpcap.packet.format.FormatUtils.ip(ip.source());
					String tempd = org.jnetpcap.packet.format.FormatUtils.ip(ip.destination());
					uniqueIP.add(temps);
					uniqueIP.add(tempd);
					uniqueSourceIP.add(temps);
					uniqueDestinationIP.add(tempd);
				}
			}
			data.addValue(uniqueIP.size(), "Overall", ""+t);
			data.addValue(uniqueSourceIP.size(), "Source IP address", ""+t);
			data.addValue(uniqueDestinationIP.size(), "Destination IP address", ""+t);
			t = t + 5;
		}
		return data;
	}

	@Override
	public DefaultCategoryDataset getIPGraph() {
		return null;
	}
}
