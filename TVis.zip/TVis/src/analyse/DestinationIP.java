package analyse;

import java.awt.Choice;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;

import org.jfree.data.category.DefaultCategoryDataset;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.protocol.network.Ip4;

public class DestinationIP implements Analyse {
	private Choice choice;
	private HashMap<String, DefaultCategoryDataset> map;
	private HashSet<String> unique;

	public DestinationIP(Choice choice_1) {
		this.choice = choice_1;
		map = new HashMap<String, DefaultCategoryDataset>();
		unique = new HashSet<String>();
	}

	@Override
	public DefaultCategoryDataset execute(LinkedList<LinkedList<PcapPacket>> allTimePackets) {
		Ip4 ip = new Ip4();
		int t = 5;
		for(LinkedList<PcapPacket> l1 : allTimePackets)
		{
			for(PcapPacket l2 : l1)
			{
				if(l2.hasHeader(ip))
				{
					String temps = org.jnetpcap.packet.format.FormatUtils.ip(ip.source());
					String tempd = org.jnetpcap.packet.format.FormatUtils.ip(ip.destination());
					unique.add(tempd);
					map.putIfAbsent(tempd, new DefaultCategoryDataset());
					DefaultCategoryDataset dTemp = map.get(tempd);
					if(dTemp.getRowIndex(temps) == -1)
					{
						dTemp.addValue(0, temps, "0");
						dTemp.addValue(1, temps, ""+t);
					}
					else if(dTemp.getColumnIndex(""+t) == -1)
					{
						dTemp.addValue(1, temps, ""+t);
					}
					else if(dTemp.getValue(temps, ""+t) == null)
					{
						dTemp.addValue(1, temps, ""+t);
					}
					else
					{
						dTemp.setValue(dTemp.getValue(temps, ""+t).intValue()+1, temps, ""+t);
					}
				}
			}
			t = t + 5;
		}
		t = t - 5;
		choice.removeAll();
		choice.setEnabled(true);
		choice.add("Choose one of the Source IP");
		for(String l:unique)
		{
			DefaultCategoryDataset d = map.get(l);
			if(d.getColumnIndex(""+t)==-1)
				d.addValue(0, d.getRowKey(0), ""+t);
			choice.add(l);
		}
		return null;
	}
	
	public DefaultCategoryDataset getIPGraph()
	{
		return map.get(choice.getSelectedItem());
	}
}
