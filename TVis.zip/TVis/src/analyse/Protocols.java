package analyse;

import java.util.LinkedList;

import org.jfree.data.category.DefaultCategoryDataset;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.protocol.network.Icmp;
import org.jnetpcap.protocol.tcpip.Tcp;
import org.jnetpcap.protocol.tcpip.Udp;

public class Protocols implements Analyse{

	@Override
	public DefaultCategoryDataset execute(LinkedList<LinkedList<PcapPacket>> allTimePackets)
	{
		Tcp tcp = new Tcp();
		Udp udp = new Udp();
		Icmp icmp = new Icmp();
		DefaultCategoryDataset data = new DefaultCategoryDataset();
		data.addValue(0, "TCP", "0");
		data.addValue(0, "UDP", "0");
		data.addValue(0, "ICMP", "0");
		int t = 5;
		for(LinkedList<PcapPacket> l1 : allTimePackets)
		{
			int tcpCount = 0;
			int udpCount = 0;
			int icmpCount = 0;
			for(PcapPacket l2 : l1)
			{
				if(l2.hasHeader(tcp))
					tcpCount++;
				if(l2.hasHeader(udp))
					udpCount++;
				if(l2.hasHeader(icmp))
					icmpCount++;
			}
			data.addValue(tcpCount, "TCP", ""+t);
			data.addValue(udpCount, "UDP", ""+t);
			data.addValue(icmpCount, "ICMP", ""+t);
			t = t + 5;
		}
		return data;
	}

	@Override
	public DefaultCategoryDataset getIPGraph() {
		return null;
	}
}
