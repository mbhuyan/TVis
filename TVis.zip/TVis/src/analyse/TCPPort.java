package analyse;

import java.util.HashSet;
import java.util.LinkedList;

import org.jfree.data.category.DefaultCategoryDataset;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.protocol.tcpip.Tcp;

public class TCPPort implements Analyse{

	@Override
	public DefaultCategoryDataset execute(LinkedList<LinkedList<PcapPacket>> allTimePackets)
	{
		Tcp tcp = new Tcp();
		DefaultCategoryDataset data = new DefaultCategoryDataset();
		data.addValue(0, "Overall TCP", "0");
		data.addValue(0, "Source TCP", "0");
		data.addValue(0, "Destination TCP", "0");
		int t = 5;
		for(LinkedList<PcapPacket> l1 : allTimePackets)
		{
			HashSet<Integer> map = new HashSet<Integer>();
			HashSet<Integer> maps = new HashSet<Integer>();
			HashSet<Integer> mapd = new HashSet<Integer>();
			for(PcapPacket l2 : l1)
			{
				if(l2.hasHeader(tcp))
				{
					map.add(tcp.source());
					map.add(tcp.destination());
					maps.add(tcp.source());
					mapd.add(tcp.destination());
				}
			}
			data.addValue(map.size(), "Overall TCP", ""+t);
			data.addValue(maps.size(), "Source TCP", ""+t);
			data.addValue(mapd.size(), "Destination TCP", ""+t);
			t = t + 5;
		}
		return data;
	}

	@Override
	public DefaultCategoryDataset getIPGraph() {
		return null;
	}
}
