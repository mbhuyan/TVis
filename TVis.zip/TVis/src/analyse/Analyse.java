package analyse;

import java.util.LinkedList;

import org.jfree.data.category.DefaultCategoryDataset;
import org.jnetpcap.packet.PcapPacket;

public interface Analyse {
	DefaultCategoryDataset execute(LinkedList<LinkedList<PcapPacket>> allTimePackets);
	public DefaultCategoryDataset getIPGraph();
}
