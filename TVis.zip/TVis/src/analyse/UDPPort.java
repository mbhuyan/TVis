package analyse;

import java.util.HashSet;
import java.util.LinkedList;

import org.jfree.data.category.DefaultCategoryDataset;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.protocol.tcpip.Udp;

public class UDPPort implements Analyse{

	@Override
	public DefaultCategoryDataset execute(LinkedList<LinkedList<PcapPacket>> allTimePackets)
	{
		Udp udp = new Udp();
		DefaultCategoryDataset data = new DefaultCategoryDataset();
		data.addValue(0, "Overall UDP", "0");
		data.addValue(0, "Source UDP", "0");
		data.addValue(0, "Destination UDP", "0");
		int t = 5;
		for(LinkedList<PcapPacket> l1 : allTimePackets)
		{
			HashSet<Integer> map = new HashSet<Integer>();
			HashSet<Integer> maps = new HashSet<Integer>();
			HashSet<Integer> mapd = new HashSet<Integer>();
			for(PcapPacket l2 : l1)
			{
				if(l2.hasHeader(udp))
				{
					map.add(udp.source());
					map.add(udp.destination());
					maps.add(udp.source());
					mapd.add(udp.destination());
				}
			}
			data.addValue(map.size(), "Overall UDP", ""+t);
			data.addValue(maps.size(), "Source UDP", ""+t);
			data.addValue(mapd.size(), "Destination UDP", ""+t);
			t = t + 5;
		}
		return data;
	}

	@Override
	public DefaultCategoryDataset getIPGraph() {
		return null;
	}
}
